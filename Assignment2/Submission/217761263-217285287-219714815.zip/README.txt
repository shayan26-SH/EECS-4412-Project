EECS 4412 Project, Phase 2

Install the packages first with python -m pip install -r requirements.txt.

Task 1: PCA
python Assignment2/Task1/task1_pca.py

Task 2: Classification
python Assignment2/Task2/task2_00_inspect_data.py
python Assignment2/Task2/task2_01_clean_data.py
python Assignment2/Task2/task2_02_label_classes.py
python Assignment2/Task2/task2_03_split_train_test.py
python Assignment2/Task2/task2_04_cross_validate_tree.py
python Assignment2/Task2/task2_05_train_evaluate_tree.py
python Assignment2/Task2/Naive_bayes/task2_06_cross_validate_naive_bayes.py
python Assignment2/Task2/Naive_bayes/task2_07_train_naive_bayes.py
python Assignment2/Task2/Naive_bayes/task2_08_evaluate_naive_bayes.py

Script 00 previews the data. Scripts 04 and 06 test one setting per run.
For the reported tuning trials, change the tree depth or alpha between runs.
Script 07 trains the final Naive Bayes model with alpha = 0.1.

Task 3: Clustering
python Assignment2/Task3/task3_clustering.py
